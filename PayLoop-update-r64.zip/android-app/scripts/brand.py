#!/usr/bin/env python3
"""يطبّق هوية PayLoop (أيقونة Adaptive + شاشة البدء) على مشروع أندرويد الذي أنشأه Capacitor.
الاستعمال: python3 scripts/brand.py <مجلد android> <مجلد assets>"""
import sys, os, re, glob
from PIL import Image
android, assets = sys.argv[1], sys.argv[2]
res = os.path.join(android, 'app', 'src', 'main', 'res')
NAVY = '#090d14'
assert os.path.isdir(res), 'res not found: ' + res
fg = Image.open(os.path.join(assets, 'android-fg-1024.png')).convert('RGBA')
legacy = Image.open(os.path.join(assets, 'android-legacy-512.png')).convert('RGBA')
logo = Image.open(os.path.join(assets, 'splash-logo.png')).convert('RGBA')
D = {'mdpi': (48, 108), 'hdpi': (72, 162), 'xhdpi': (96, 216), 'xxhdpi': (144, 324), 'xxxhdpi': (192, 432)}
def save(img, path, size):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.resize((size, size), Image.LANCZOS).save(path)
for d, (leg, fgs) in D.items():
    base = os.path.join(res, 'mipmap-' + d)
    save(legacy, os.path.join(base, 'ic_launcher.png'), leg)
    save(legacy, os.path.join(base, 'ic_launcher_round.png'), leg)
    save(fg, os.path.join(base, 'ic_launcher_foreground.png'), fgs)
# Adaptive icon (Android 8+): خلفية كحلية + طبقة الشعار
adaptive = ('<?xml version="1.0" encoding="utf-8"?>\n<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
            '    <background android:drawable="@color/ic_launcher_background"/>\n'
            '    <foreground android:drawable="@mipmap/ic_launcher_foreground"/>\n</adaptive-icon>\n')
any26 = os.path.join(res, 'mipmap-anydpi-v26'); os.makedirs(any26, exist_ok=True)
for n in ('ic_launcher.xml', 'ic_launcher_round.xml'):
    open(os.path.join(any26, n), 'w', encoding='utf-8').write(adaptive)
vals = os.path.join(res, 'values'); os.makedirs(vals, exist_ok=True)
open(os.path.join(vals, 'ic_launcher_background.xml'), 'w', encoding='utf-8').write(
    '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <color name="ic_launcher_background">%s</color>\n</resources>\n' % NAVY)
# شاشة البدء: خلفية كحلية + الشعار والاسم في المنتصف (بلا تمديد)
dr = os.path.join(res, 'drawable'); os.makedirs(dr, exist_ok=True)
w = 720; logo.resize((w, int(logo.height * w / logo.width)), Image.LANCZOS).save(os.path.join(dr, 'pl_logo.png'))
open(os.path.join(dr, 'pl_splash.xml'), 'w', encoding='utf-8').write(
    '<?xml version="1.0" encoding="utf-8"?>\n<layer-list xmlns:android="http://schemas.android.com/apk/res/android">\n'
    '    <item><shape android:shape="rectangle"><solid android:color="%s"/></shape></item>\n'
    '    <item android:gravity="center"><bitmap android:src="@drawable/pl_logo" android:gravity="center"/></item>\n</layer-list>\n' % NAVY)
solid = Image.new('RGBA', (8, 8), NAVY)
for f in glob.glob(os.path.join(res, 'drawable*', 'splash.png')):
    solid.save(f)
# اربط الثيم بالشاشة الجديدة
patched = False
for f in glob.glob(os.path.join(res, 'values*', 'styles.xml')):
    s = open(f, encoding='utf-8').read()
    if '@drawable/splash' in s:
        open(f, 'w', encoding='utf-8').write(s.replace('@drawable/splash', '@drawable/pl_splash')); patched = True
        m = re.search(r'<style name="AppTheme\.NoActionBarLaunch" parent="([^"]+)"', s)
        if m:
            v31 = os.path.join(res, 'values-v31'); os.makedirs(v31, exist_ok=True)
            open(os.path.join(v31, 'pl_splash.xml'), 'w', encoding='utf-8').write(
                '<?xml version="1.0" encoding="utf-8"?>\n<resources>\n    <style name="AppTheme.NoActionBarLaunch" parent="%s">\n'
                '        <item name="android:background">@drawable/pl_splash</item>\n'
                '        <item name="android:windowSplashScreenBackground">%s</item>\n'
                '        <item name="android:windowSplashScreenIconBackgroundColor">%s</item>\n    </style>\n</resources>\n' % (m.group(1), NAVY, NAVY))
print('branding applied; styles patched =', patched)
